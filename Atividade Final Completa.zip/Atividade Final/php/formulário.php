<?php
// process_form.php

// Configurações do banco de dados
$servername = "localhost";
$username = "seu_usuario";
$password = "sua_senha";
$dbname = "nome_do_banco";

// Receber dados do formulário
$input = json_decode(file_get_contents('php://input'), true);

$name = $input['name'];
$email = $input['email'];
$message = $input['message'];

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Falha na conexão: " . $conn->connect_error]));
}

// Preparar e executar a query
$sql = "INSERT INTO contatos (nome, email, mensagem, data_envio) VALUES (?, ?, ?, NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $name, $email, $message);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Mensagem enviada com sucesso!"]);
} else {
    echo json_encode(["success" => false, "message" => "Erro ao enviar mensagem: " . $stmt->error]);
}

// Fechar conexões
$stmt->close();
$conn->close();
?>